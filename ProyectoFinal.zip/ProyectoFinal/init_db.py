import sqlite3

# Conectar o crear la base de datos
conn = sqlite3.connect('attacks.db')
cursor = conn.cursor()

# Crear la tabla de ataques si no existe
cursor.execute('''
CREATE TABLE IF NOT EXISTS attacks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    source_ip TEXT,
    destination_ip TEXT,
    attack_type TEXT,
    details TEXT
)
''')

# Insertar datos de prueba
cursor.execute("INSERT INTO attacks (timestamp, source_ip, destination_ip, attack_type, details) VALUES (?, ?, ?, ?, ?)",
               ("2025-03-04 10:00:00", "192.168.1.10", "192.168.1.20", "DDoS", "Tráfico sospechoso detectado"))

# Guardar y cerrar
conn.commit()
conn.close()

print("Base de datos inicializada con éxito.")
