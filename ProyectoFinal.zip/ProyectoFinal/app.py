from flask import Flask, render_template, Response
from scapy.all import sniff
import threading
import time

app = Flask(__name__)

# Lista para almacenar los paquetes detectados
attack_logs = []

# Umbral para detectar un posible ataque (por ejemplo, 10 paquetes ICMP en un corto periodo)
icmp_packet_count = 0
last_icmp_time = time.time()

# Direcciones IP de interés (sin la IP 192.168.56.103)
TARGET_IPS = ["192.168.56.101", "192.168.56.102"]

def packet_callback(packet):
    """Función que se ejecuta al capturar un paquete."""
    global attack_logs, icmp_packet_count, last_icmp_time
    attack_info = {
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
        "type": "Desconocido",
        "source": packet[0][1].src if packet.haslayer("IP") else "No-IP",
        "destination": packet[0][1].dst if packet.haslayer("IP") else "No-IP",
        "protocol": None,
        "src_port": None, "dst_port": None,
    }

    # Asegurarse de que el paquete tenga una capa IP
    if packet.haslayer("IP"):
        source_ip = packet[0][1].src

        # Si el paquete proviene de las IPs que nos interesan (sin la 192.168.56.103)
        if source_ip in TARGET_IPS:
            attack_info["protocol"] = packet.proto

            if packet.haslayer("TCP"):
                attack_info["src_port"] = packet["TCP"].sport
                attack_info["dst_port"] = packet["TCP"].dport
                # Detección de SYN flood (escaneo de puertos)
                if packet["TCP"].flags == 2:  # SYN flag
                    attack_info["type"] = "Port Scan"
            elif packet.haslayer("UDP"):
                attack_info["src_port"] = packet["UDP"].sport
                attack_info["dst_port"] = packet["UDP"].dport
                attack_info["type"] = "Posible DDoS (UDP)"
            elif packet.haslayer("ICMP"):
                attack_info["type"] = "Posible Ping Flood (ICMP)"

                # Controlar el flujo de paquetes ICMP para evitar alertas falsas
                current_time = time.time()
                if current_time - last_icmp_time < 1:
                    icmp_packet_count += 1
                else:
                    icmp_packet_count = 1  # Reset count after 1 second

                last_icmp_time = current_time

                if icmp_packet_count > 10:  # Umbral para el flood
                    attack_info["type"] = "Posible Ping Flood (ICMP)"

    else:
        attack_info["protocol"] = "No-IP"

    attack_logs.append(attack_info)
    if len(attack_logs) > 10:  # Mantener solo los últimos 10 registros
        attack_logs.pop(0)

def start_sniffing():
    """Hilo separado para capturar paquetes en tiempo real."""
    sniff(prn=packet_callback, store=0)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/logs')
def logs():
    """Devuelve los registros de ataques en texto plano para actualizar en tiempo real."""
    global attack_logs
    response = "<h3>Últimos 10 registros:</h3>"

    # Mostrar los registros de ataque
    for log in attack_logs:
        response += f"{log['timestamp']} | {log['type']} | {log['source']}:{log['src_port']} -> {log['destination']}:{log['dst_port']}<br>"

    return response

if __name__ == '__main__':
    # Iniciar la captura de paquetes en un hilo separado
    sniff_thread = threading.Thread(target=start_sniffing, daemon=True)
    sniff_thread.start()

    # Cambia el puerto de 5000 a otro puerto, por ejemplo 5001
    app.run(debug=True, host="0.0.0.0", port=5006)
