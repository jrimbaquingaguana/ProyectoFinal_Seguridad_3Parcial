import sqlite3
from scapy.all import sniff, IP

# Función para guardar en la base de datos
def log_attack(timestamp, src_ip, dst_ip, attack_type, details):
    conn = sqlite3.connect('attacks.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO attacks (timestamp, source_ip, destination_ip, attack_type, details) VALUES (?, ?, ?, ?, ?)",
                   (timestamp, src_ip, dst_ip, attack_type, details))
    conn.commit()
    conn.close()

# Callback para procesar los paquetes
def packet_callback(packet):
    if IP in packet:
        src_ip = packet[IP].src
        dst_ip = packet[IP].dst
        log_attack("2025-03-04 11:00:00", src_ip, dst_ip, "Posible Escaneo de Puertos", "Paquete sospechoso detectado")

# Iniciar el sniffer
print("Iniciando la captura de paquetes...")
sniff(prn=packet_callback, store=0)
